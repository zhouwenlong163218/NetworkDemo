package com.example.network;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

public class HttpOkActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String IP_URL = "http://ip.taobao.com/service/getIpInfo.php?ip=117.136.45.111";

    private TextView ok;
    private ScrollView okView;
    private ImageView okImage;
    private Button btnOkGet,okPost,okUp,okDown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ok);
        initView();
    }

    private void initView() {
        ok = findViewById(R.id.tv_ok);
        okView = findViewById(R.id.sv_okView);
        okImage = findViewById(R.id.iv_okImage);
        btnOkGet = findViewById(R.id.btn_okGet);
        okPost = findViewById(R.id.btn_okPost);
        okUp =findViewById(R.id.btn_okUp);
        okDown = findViewById(R.id.btn_okDown);

        btnOkGet.setOnClickListener(this);
        okPost.setOnClickListener(this);
        okUp.setOnClickListener(this);
        okDown.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_get:
                String path = getFilesDir().getAbsolutePath();
                break;
            case R.id.btn_post:
                break;
            case R.id.btn_up:
                break;
            case R.id.btn_down:
                break;
        }
    }
}

