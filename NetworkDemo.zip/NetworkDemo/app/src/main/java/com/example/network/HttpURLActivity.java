package com.example.network;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

public class HttpURLActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String IP_URL = "http://ip.taobao.com/service/getIpInfo.php?ip=117.136.45.111";

    private TextView url;
    private ScrollView view;
    private ImageView image;
    private Button btnGet,post,up,down;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_url);

        initView();
    }

    private void initView() {
        url = findViewById(R.id.tv_url);
        view = findViewById(R.id.sv_view);
        image = findViewById(R.id.iv_image);
        btnGet = findViewById(R.id.btn_get);
        post = findViewById(R.id.btn_post);
        up =findViewById(R.id.btn_up);
        down = findViewById(R.id.btn_down);

        btnGet.setOnClickListener(this);
        post.setOnClickListener(this);
        up.setOnClickListener(this);
        down.setOnClickListener(this);

        Glide.with(this)
                .load("http://www.baidu.com/img/bd_logo1.png")
                .placeholder(R.mipmap.ic_launcher_round)
                .into(image);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_get:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final String result = NetworkUtils.get(IP_URL);
                        Log.d("MainActivity",result);
                        if (result != null){
                            url.post(new Runnable() {
                                @Override
                                public void run() {
                                    url.setText(result);
                                }
                            });
                        }else {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    url.setText("数据为null");
                                }
                            });
                        }
                    }
                }).start();
                break;
            case R.id.btn_post:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        List<NameValuePair> params = new ArrayList<>();
                        params.add(new BasicNameValuePair("ip","117.136.45.111"));
                        final String result = NetworkUtils.post(IP_URL,params);
                        if (result != null){
                            Log.d("MainActivity",result);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    url.setText(result);
                                }
                            });
                        }else {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    url.setText("请求失败，未获得数据");
                                }
                            });
                        }
                    }
                }).start();
                break;
            case R.id.btn_up:
                break;
            case R.id.btn_down:
                break;
        }
    }
}
